from django.shortcuts import render, get_object_or_404
from .forms import VideoForm
from .models import Videos,showsimage
from django.http import HttpResponse, HttpResponseRedirect
from django.http import HttpResponse
from django.core.mail import EmailMessage
from django.core.mail import send_mail
from django.conf import settings
from django.shortcuts import redirect
from django.contrib import messages



def index(request):
    images = showsimage.objects
    return render(request ,"index.htm",{'videos' : images})

def allvideos(request):
    video = Videos.objects
    return render(request,"allvideos.htm",{'allvideos': video})

def videoid(request,silver_id):
    video = get_object_or_404(Videos,pk=silver_id)
    return render(request,"popupvideo.htm",{'allvideos': video})

def projects(request):
    video = Videos.objects
    return render(request,"projects.htm",{'videos':video})

def send_email(request):
    return render(request,"message.htm")

def contact(request):
    subject = request.POST['name']
    message = request.POST['message']
    recipient = settings.EMAIL_HOST_USER
    aana = recipient
    recipient = [recipient,]
    email_from = request.POST['mailing']
    jaana = [email_from,]
    send_mail( subject, message, email_from, recipient )
    send_mail('Silver Oak Entertainment','You will be Contacted Soon',aana,jaana)
    messages.success(request, 'Successfully Sent The Message!')
    return redirect('send_email')    


