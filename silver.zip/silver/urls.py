from django.urls import path
from . import views

urlpatterns = [
    path('', views.index , name="index"),
    path('project/', views.allvideos, name="allvideos"),
    path('project/<int:silver_id>/',views.videoid,name="popupvideos"),
    path('projects/',views.projects,name="projects"),
    path('message/',views.send_email,name="send_email"),
    path('message/emails',views.contact,name="contact"),
]