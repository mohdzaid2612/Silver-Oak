from django.contrib import admin

from .models import Videos, showsimage

admin.site.register(Videos)
admin.site.register(showsimage)
