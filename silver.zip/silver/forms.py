from django import forms
from .models import Videos
class VideoForm(forms.ModelForm):
    class Meta:
        model= Videos
        fields= ["videoo","summary","image"]